/**   
* Copyright (C) 2015 Orange   
*   
* This software is distributed under the terms and conditions of the 'Apache-2.0'   
* license which can be found in the file 'LICENSE' in this package distribution   
* or at 'http://www.apache.org/licenses/LICENSE-2.0'.   
*/   
   
//========================================================================================================================   
//   
//     CONFIGURATION CONSTANTS   
//   
//========================================================================================================================   
   
var _CONFIG = {   
  //----- datasource identifier for the concerned device   
  datasource : "6ab862c8c74f4cf38b71024f1e0ea63d",
   
  //----- AES encryption/decryption cipher application session key (use "" for no encryption)   
  appSKey : "163230fc849547702e8bdb9572750b4a",
   
  //----- datavenue server url   
  datavenueUrl: "https://api.orange.com/datavenue/v1",   
   
  //----- security keys   
  X_OAPI_Key : "5D7GUhwugTmZFjT4nSkM7nzWqWHHSO3G",
  X_ISS_Key : "587fc976c3bf496fb2d34b8ed5946504",
   
  //----- maximum time for a request (in milliseconds, use 0 for no timeout)   
  requestTimeout: 8000,   
   
  //----- Command Fport   
  CmdFPort: 5,   
   
  //----- light sensor measurement range   
  lightMin:   10,   //  darkness one hundred per cent   
  lightMax: 1100      
   
};   
//========================================================================================================================   
   
   
   
   
   
   
   
   
   
   
   
   
   
