This code is part of the sample application provided with Orange IoT Starter KiT based on LoRa(R) technology.
It is composed of an arduino code (to be loaded on the starter kit), and a Web App code.

The device sends periodically -every 3 minutes- a message containing the last luminosity sensor value, and can process a command coming from the Web app to light on/off a led.

(this part) The web application is used to pull datas sent by the starter kit and command a Led on the starter KiT.