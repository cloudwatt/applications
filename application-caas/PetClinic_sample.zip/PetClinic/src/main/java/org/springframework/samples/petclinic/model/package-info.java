/**
 * The classes in this package represent PetClinic's business layer.
 */
package org.springframework.samples.petclinic.model;

