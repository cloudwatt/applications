#!/bin/bash
set -e

	if [ -n "$MYSQL_PORT_3306_TCP" ]; then
		if [ -z "$PETCLINIC_DB_HOST" ]; then
			PETCLINIC_DB_HOST='mysql'
		else
			echo >&2 'warning: both PETCLINIC_DB_HOST and MYSQL_PORT_3306_TCP found'
			echo >&2 "  Connecting to PETCLINIC_DB_HOST ($PETCLINIC_DB_HOST)"
			echo >&2 '  instead of the linked mysql container'
		fi
	fi

	if [ -z "$PETCLINIC_DB_HOST" ]; then
		echo >&2 'error: missing PETCLINIC_DB_HOST and MYSQL_PORT_3306_TCP environment variables'
		echo >&2 '  Did you forget to --link some_mysql_container:mysql or set an external db'
		echo >&2 '  with -e PETCLINIC_DB_HOST=hostname:port?'
		exit 1
	fi

	# if we're linked to MySQL and thus have credentials already, let's use them
	: ${PETCLINIC_DB_USER:=${MYSQL_ENV_MYSQL_USER:-root}}
	if [ "$PETCLINIC_DB_USER" = 'root' ]; then
		: ${PETCLINIC_DB_PASSWORD:=$MYSQL_ENV_MYSQL_ROOT_PASSWORD}
	fi
	: ${PETCLINIC_DB_PASSWORD:=$MYSQL_ENV_MYSQL_PASSWORD}

	if [ -z "$PETCLINIC_DB_PASSWORD" ]; then
		echo >&2 'error: missing required PETCLINIC_DB_PASSWORD environment variable'
		echo >&2 '  Did you forget to -e PETCLINIC_DB_PASSWORD=... ?'
		echo >&2
		echo >&2 '  (Also of interest might be PETCLINIC_DB_USER and PETCLINIC_DB_NAME.)'
		exit 1
	fi

sed -i 's/\/hsqldb/\/mysql/' /tmp/petclinic/WEB-INF/classes/spring/data-access.properties
sed -i '15,25 s/^j/#j/' /tmp/petclinic/WEB-INF/classes/spring/data-access.properties
sed -i '25,35 s/#j/j/' /tmp/petclinic/WEB-INF/classes/spring/data-access.properties
sed -i "s|127.0.0.1|$PETCLINIC_DB_HOST|g" /tmp/petclinic/WEB-INF/classes/spring/data-access.properties
sed -i "s|=root|=$PETCLINIC_DB_USER|g" /tmp/petclinic/WEB-INF/classes/spring/data-access.properties
sed -i "s|=petclinic|=$PETCLINIC_DB_PASSWORD|g" /tmp/petclinic/WEB-INF/classes/spring/data-access.properties
cd /tmp/petclinic
zip -r /usr/local/tomcat/webapps/petclinic.war .

# test connection with db host
tries=40
while ! echo 'SELECT 1' | mysql -h $PETCLINIC_DB_HOST -u$PETCLINIC_DB_USER -p$PETCLINIC_DB_PASSWORD  petclinic  &> /dev/null; do
    (( tries-- ))
    if [ $tries -le 0 ]; then
        echo -e  "\t Giving up trying to contact MySQL, self-destuction"
        exit 1
    fi
    echo -e "\t Waiting for MySQL to be ready"
    sleep 3
done


/usr/local/tomcat/bin/catalina.sh run
